import { Component } from 'react'
import './TodoItem.css'

class TodoItem extends Component {
	render() {
		return (
			<div >
				<ul>
					{this.props.todos.map((todo) => {
						return (
                            <div key={todo.id} className='todo-item'>
                                  <li
								className={`${
									todo.complete ? 'completed' : 'item'
								}`}
								
							>
								{todo.text}
								{todo.date}
								<input
                                type='checkbox'
									id={todo.id}
									onClick={this.props.CompleteHandler}
								/>
								<button
									id={todo.id}
									onClick={this.props.deleteHandler.bind(this)}
								>
									Delete
								</button>
							</li>
                            </div>
						)
					})}
				</ul>
			</div>
		)
	}
}
export default TodoItem
